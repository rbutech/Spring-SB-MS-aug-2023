package com.ds.sms_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SmsMysqlApplication {

    public static void main(final String[] args) {
        SpringApplication.run(SmsMysqlApplication.class, args);
    }

}
