package com.ds.sms_oracledb.repos;

import com.ds.sms_oracledb.domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StudentRepository extends JpaRepository<Student, Long> {
}
