package com.ds.sms_mongo.repos;

import com.ds.sms_mongo.domain.Student;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface StudentRepository extends MongoRepository<Student, Long> {
}
