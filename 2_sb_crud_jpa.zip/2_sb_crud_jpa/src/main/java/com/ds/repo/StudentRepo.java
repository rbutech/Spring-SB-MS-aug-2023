package com.ds.repo;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ds.beans.Student;
@Repository
public interface StudentRepo extends JpaRepository<Student, BigInteger> {
public Student findByEmail(String email);
public Student findByName(String name);
public Student findByAddress(String address);
public Student findByNameAndEmail(String name,String email);
}
