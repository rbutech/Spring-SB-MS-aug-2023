package com.ds.beans;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "STUDENT_DS_TAB", schema = "system")
@Data
public class Student implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5332663291884831070L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private BigInteger id;
	private String name;
	private String email;
	private String address;
	public BigInteger getId() {
		return id;
	}
	public void setId(BigInteger id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
