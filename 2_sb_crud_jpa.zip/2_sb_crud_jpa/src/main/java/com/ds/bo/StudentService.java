package com.ds.bo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ds.beans.Student;
import com.ds.repo.StudentRepo;

@Service
//@CacheConfig(cacheNames = "Student")
public class StudentService {
	@Autowired
	StudentRepo repo;
	//@CachePut(value = "Student", key = "#Student.id")
	public Student createStudent(Student student) {
		System.out.println("createStudent method");
		return repo.save(student);
	}
	//@CachePut(value = "Student", key = "#Student.id")
	public Student updateStudent(Student student) {
		System.out.println("updateStudent method");
		return repo.save(student);
	}
	//@CacheEvict(value = "Student", key = "#Student.id")
	public void deleteStudent(Student student) {
		System.out.println("deleteStudent method");
		repo.delete(student);
	}
	//@Cacheable
	public Iterable<Student> findAll() {
		System.out.println("findAll method");
		return repo.findAll();
	}
	//@Cacheable
	public Student findStudentByName(String name) {
		System.out.println("findStudentByName method");
		return repo.findByName(name);
	}
	//@Cacheable
	public Student findStudentByEmail(String email) {
		System.out.println("findStudentByEmail method");
		return repo.findByEmail(email);
	}
	//@Cacheable
	public Student findStudentByAddress(String address) {
		System.out.println("findStudentByAddress method");
		return repo.findByAddress(address);
	}
	public Student findStudentByNameAndEmail(String name,String email) {
		System.out.println("findStudentByAddress method");
		return repo.findByNameAndEmail(name, email);
	}
}
