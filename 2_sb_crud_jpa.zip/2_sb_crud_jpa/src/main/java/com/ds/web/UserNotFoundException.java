package com.ds.web;

public class UserNotFoundException extends Exception {
	String message;

	public UserNotFoundException(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "UserNotFoundException [message=" + message + "]";
	}

}
