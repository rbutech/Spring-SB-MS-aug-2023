package com.ds.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ds.beans.Student;
import com.ds.bo.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;

	@PostMapping("/student")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
		student = service.createStudent(student);
		System.out.println("rest service..");
		return new ResponseEntity<Student>(student, HttpStatus.CREATED);
	}

	@PutMapping("/student")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student) throws UserNotFoundException {
		Student studentResp = service.findStudentByName(student.getName());
		if (null == studentResp) {
			throw new UserNotFoundException("No record found");

		} else if (studentResp != null || studentResp.getName() != null) {
			student = service.updateStudent(student);
		}

		return new ResponseEntity<Student>(student, HttpStatus.OK);
	}

	@DeleteMapping("/student")
	public ResponseEntity<String> deleteStudent(@RequestBody Student student) {
		service.deleteStudent(student);
		return new ResponseEntity<String>("student record deleted successfully", HttpStatus.OK);
	}

	@GetMapping("/student")
	public ResponseEntity<Iterable<Student>> findAllStudent() {
		return new ResponseEntity<Iterable<Student>>(service.findAll(), HttpStatus.OK);
	}

	@GetMapping("/student/{name}")
	public ResponseEntity<Student> findByName(@PathVariable("name") String name) {
		return new ResponseEntity<Student>(service.findStudentByName(name), HttpStatus.OK);
	}

	@GetMapping("/studentEmail/{email}")
	public ResponseEntity<Student> findByEmail(@PathVariable("email") String email) {
		return new ResponseEntity<Student>(service.findStudentByEmail(email), HttpStatus.OK);
	}
	@GetMapping("/studentAddres/{address}")
	public ResponseEntity<Student> findByAddress(@PathVariable("address") String address) {
		return new ResponseEntity<Student>(service.findStudentByAddress(address), HttpStatus.OK);
	}

}
